var searchData=
[
  ['timestamp_5fus_1064',['timestamp_us',['../structlr11xx__wifi__basic__complete__result__s.html#af38aa2f52e2b1940b3083fca3a3709af',1,'lr11xx_wifi_basic_complete_result_s::timestamp_us()'],['../structlr11xx__wifi__extended__full__result__t.html#a8c92409773e6fbe6d81c1f0ca0411d59',1,'lr11xx_wifi_extended_full_result_t::timestamp_us()']]]
];
