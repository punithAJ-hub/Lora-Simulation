var searchData=
[
  ['nb_5fpkt_5fcrc_5ferror_1034',['nb_pkt_crc_error',['../structlr11xx__radio__stats__gfsk__s.html#ad50af4e764de2de53023c399213106b2',1,'lr11xx_radio_stats_gfsk_s::nb_pkt_crc_error()'],['../structlr11xx__radio__stats__lora__s.html#a00cff2925333e3782737c3d1d4a741eb',1,'lr11xx_radio_stats_lora_s::nb_pkt_crc_error()']]],
  ['nb_5fpkt_5ffalsesync_1035',['nb_pkt_falsesync',['../structlr11xx__radio__stats__lora__s.html#ad1c1add9160223765d4f950c701a30e1',1,'lr11xx_radio_stats_lora_s']]],
  ['nb_5fpkt_5fheader_5ferror_1036',['nb_pkt_header_error',['../structlr11xx__radio__stats__lora__s.html#a9a3f6d2bdfed1a0512de7c02b60db190',1,'lr11xx_radio_stats_lora_s']]],
  ['nb_5fpkt_5flen_5ferror_1037',['nb_pkt_len_error',['../structlr11xx__radio__stats__gfsk__s.html#a2be1db51e2da3231935aacaea8a69407',1,'lr11xx_radio_stats_gfsk_s']]],
  ['nb_5fpkt_5freceived_1038',['nb_pkt_received',['../structlr11xx__radio__stats__gfsk__s.html#ac17ef52c249ca14847b59da38020ad58',1,'lr11xx_radio_stats_gfsk_s::nb_pkt_received()'],['../structlr11xx__radio__stats__lora__s.html#a2a132432d5fd0e3aeef748d69f19af47',1,'lr11xx_radio_stats_lora_s::nb_pkt_received()']]]
];
