var searchData=
[
  ['timestamp_5fus_718',['timestamp_us',['../structlr11xx__wifi__basic__complete__result__s.html#af38aa2f52e2b1940b3083fca3a3709af',1,'lr11xx_wifi_basic_complete_result_s::timestamp_us()'],['../structlr11xx__wifi__extended__full__result__t.html#a8c92409773e6fbe6d81c1f0ca0411d59',1,'lr11xx_wifi_extended_full_result_t::timestamp_us()']]],
  ['tx_5fdone_5firq_5fprocessing_5ftime_5fin_5fus_719',['TX_DONE_IRQ_PROCESSING_TIME_IN_US',['../lr11xx__radio__timings_8c.html#ac60f13fb9aaca69698cbf0fd558fb3bb',1,'lr11xx_radio_timings.c']]]
];
