var searchData=
[
  ['rate_1048',['rate',['../structlr11xx__wifi__extended__full__result__t.html#a559dc0524c49eb18ce6a81a3871c1ca6',1,'lr11xx_wifi_extended_full_result_t']]],
  ['rssi_5favg_5fin_5fdbm_1049',['rssi_avg_in_dbm',['../structlr11xx__radio__pkt__status__gfsk__s.html#a7ea83f93dee3286b32f6598f1558bcb8',1,'lr11xx_radio_pkt_status_gfsk_s']]],
  ['rssi_5fpkt_5fin_5fdbm_1050',['rssi_pkt_in_dbm',['../structlr11xx__radio__pkt__status__lora__s.html#a8c3e428b52fb80ccc95ed4aacc588eab',1,'lr11xx_radio_pkt_status_lora_s']]],
  ['rssi_5fsync_5fin_5fdbm_1051',['rssi_sync_in_dbm',['../structlr11xx__radio__pkt__status__gfsk__s.html#ae7c44fa09673d68c8176e32ab1713d1a',1,'lr11xx_radio_pkt_status_gfsk_s']]],
  ['rx_5fcapture_5fus_1052',['rx_capture_us',['../structlr11xx__wifi__cumulative__timings__s.html#a9d220fc97d080e536da711257f0f5a90',1,'lr11xx_wifi_cumulative_timings_s']]],
  ['rx_5fcorrelation_5fus_1053',['rx_correlation_us',['../structlr11xx__wifi__cumulative__timings__s.html#a2d716aed6c7eaa5089df8649f066c2eb',1,'lr11xx_wifi_cumulative_timings_s']]],
  ['rx_5fdetection_5fus_1054',['rx_detection_us',['../structlr11xx__wifi__cumulative__timings__s.html#aec81e80a202bdcb09df0c0a36a2aae7d',1,'lr11xx_wifi_cumulative_timings_s']]],
  ['rx_5flen_5fin_5fbytes_1055',['rx_len_in_bytes',['../structlr11xx__radio__pkt__status__gfsk__s.html#ab63e9d46ab39d6bc7d960e5249d7f630',1,'lr11xx_radio_pkt_status_gfsk_s']]]
];
