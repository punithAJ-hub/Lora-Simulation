var searchData=
[
  ['sf_505',['sf',['../structsx126x__mod__params__lora__s.html#a7ad92739a2f6aa9fe6f570b16d8f298c',1,'sx126x_mod_params_lora_s']]],
  ['signal_5frssi_5fpkt_5fin_5fdbm_506',['signal_rssi_pkt_in_dbm',['../structsx126x__pkt__status__lora__s.html#a657a64270fb4c39564b6dbf5b943febe',1,'sx126x_pkt_status_lora_s']]],
  ['snr_5fpkt_5fin_5fdb_507',['snr_pkt_in_db',['../structsx126x__pkt__status__lora__s.html#a043d976477a2f198807dd5a3eb3b0bfd',1,'sx126x_pkt_status_lora_s']]],
  ['sync_5fword_508',['sync_word',['../structlr__fhss__v1__params__s.html#a5a0062b30931cbfc2ebc078e5f571e57',1,'lr_fhss_v1_params_s']]],
  ['sync_5fword_5flen_5fin_5fbits_509',['sync_word_len_in_bits',['../structsx126x__pkt__params__gfsk__s.html#a4183f9fceec6331050ed94031da98c5c',1,'sx126x_pkt_params_gfsk_s']]]
];
