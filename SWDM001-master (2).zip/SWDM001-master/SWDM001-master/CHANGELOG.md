# Changelog

All notable changes to this project will be documented in this file.

## [1.3.0] - 2023-03-13

### Changed

- Updated LR11xx driver to version v2.3.0

## [1.2.0] - 2023-03-13

### Added

- Support for LR1120 and LR1121 transceivers

## [1.0.1] - 2022-02-25

### General

- Initial version

